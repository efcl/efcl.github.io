<!-- SBM Popular Entry -->
<a href="<?= $add['hatena'] ?>" title="add to hatena">
    <img style="vertical-align: middle;" src="<?= $icon['hatena'] ?>" alt="add to hatena" /></a>
<a href="javascript:void(0);" title="hatena.comment">
    <img style="vertical-align: middle;" src="<?= $icon['popup'] ?>" alt="hatena.comment" onclick="<?= $popup ?>" /></a>
(<a href="<?= $link['hatena'] ?>" title="hatena::BookmarkCount"><?= $count['hatena'] ?></a>)

<a href="<?= $add['delicious'] ?>" title="add to del.icio.us">
    <img style="vertical-align: middle;" src="<?= $icon['delicious'] ?>" alt="add to del.icio.us" /></a>
(<a href="<?= $link['delicious'] ?>" title="delicious::BookmarkCount"><?= $count['delicious'] ?></a>)

<a href="<?= $add['livedoor'] ?>" title="add to livedoor.clip">
    <img style="vertical-align: middle;" src="<?= $icon['livedoor'] ?>" alt="add to livedoor.clip" /></a>
(<a href="<?= $link['livedoor'] ?>" title="livedoor::BookmarkCount"><?= $count['livedoor'] ?></a>)

<a href="<?= $add['yahoo'] ?>" title="add to Yahoo!Bookmark">
    <img style="vertical-align: middle;" src="<?= $icon['yahoo'] ?>" alt="add to Yahoo!Bookmark" /></a>
(<a href="<?php print $link['yahoo'] ?>" title="Yahoo!::BookmarkCount"><?php print $count['yahoo'] ?></a>) 

Total: <?= $count['sum'] ?>
<!-- /SBM Popular Entry -->