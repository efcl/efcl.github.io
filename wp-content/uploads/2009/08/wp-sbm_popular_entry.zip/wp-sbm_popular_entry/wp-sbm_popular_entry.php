<?php

/*
Plugin Name: SBM Popular Entry
Plugin URI: http://aoina.com/archives/18
Description: SBM Popular Entry
Author: aoina
Version: 1.5
Author URI: http://aoina.com
*/





$SBM_PopularEntry = new SBM_PopularEntry();

add_filter('manage_posts_columns', array(&$SBM_PopularEntry, 'manage_posts_columns'));
add_action('manage_posts_custom_column', array(&$SBM_PopularEntry, 'manage_posts_custom_column'));

add_action('wp_head',  array(&$SBM_PopularEntry, 'wp_head'));
add_action('wp_head', array(&$SBM_PopularEntry, 'get_count'));

unset($SBM_PopularEntry);


class SBM_PopularEntry
{
    var $plugin_url;
    var $post;
    var $post_meta;
    var $permalink;
    var $postlink;
    var $urllink;
    var $key;
    
    
    /**
     *
     *
     */
    function SBM_PopularEntry()
    {
        $this->plugin_url = get_option('siteurl')."/wp-content/plugins/wp-sbm_popular_entry/";
        $this->key = "SBM_count";
    }
    
    
    /**
     * 管理画面の記事リストの<th>部分のアイコン
     *
     */
    function manage_posts_columns($posts_columns)
    {
        $posts_columns['SBM_hatena']    = '<img src="'.$this->plugin_url.'hatena.gif" alt="hatena" />';
        $posts_columns['SBM_delicious'] = '<img src="'.$this->plugin_url.'delicious.gif" alt="delicious" />';
        $posts_columns['SBM_livedoor']  = '<img src="'.$this->plugin_url.'livedoor.gif" alt="livedoor" />';
        $posts_columns['SBM_yahoo']     = '<img src="'.$this->plugin_url.'yahoo.gif" alt="yahoo" />';
        
        return $posts_columns;
    }
    
    
    /**
     * 管理画面の記事リストに被ブックマーク数を表示
     *
     */
    function manage_posts_custom_column($column_name)
    {
        global $post;
        
        if(@$this->post->ID != $post->ID){
            $this->post = $post;
            $this->permalink   = get_permalink();
            $this->urllink['hatena']    = "http://b.hatena.ne.jp/entry/".$this->permalink;
            $this->urllink['delicious'] = "http://delicious.com/url/".md5($this->permalink);
            $this->urllink['livedoor']  = "http://clip.livedoor.com/page/".$this->permalink;
            $this->urllink['yahoo']     = "http://bookmarks.yahoo.co.jp/url?url=".urlencode($this->permalink);
            
            $meta = get_post_meta($this->post->ID, $this->key, 1);
            $this->post_meta = explode("<>", $meta);
        }

        switch($column_name) {
            case 'SBM_hatena':
                if($this->post_meta[2])
                    echo '<div style="text-align:center"><a href="'.$this->urllink['hatena'].'">'.($this->post_meta[2]).'</a></div>';
                break;
            case 'SBM_delicious':
                if($this->post_meta[3])
                    echo '<div style="text-align:center"><a href="'.$this->urllink['delicious'].'">'.($this->post_meta[3]).'</a></div>';
                break;
            case 'SBM_livedoor':
                if($this->post_meta[4])
                    echo '<div style="text-align:center"><a href="'.$this->urllink['livedoor'].'">'.($this->post_meta[4]).'</a</div>';
                break;
            case 'SBM_yahoo':
                if($this->post_meta[5])
                    echo '<div style="text-align:center"><a href="'.$this->urllink['yahoo'].'">'.($this->post_meta[5]).'</a></div>';
                break;
            default:
                break;
        }
    }
    
    
    /**
     * 記事表示時に各ブクマサイトより被ブックマーク数をGET
     *
     */
    function get_count()
    {
        global $post;
        
        if (!is_single() && !is_page) return false;
        if (!$post->ID > 0) return false;
        
        $permalink = get_permalink();
        $flg = get_post_meta($post->ID, $this->key, 1);
        if(!$flg){
            $flg = "00000<>0<>0<>0<>0<>0<>0";
            add_post_meta($post->ID, $this->key, $flg, 1);
        }
        $meta = explode("<>",$flg);
        
        if( $meta[1] > time()-60*60 ) return false;
        
        $new_meta['hatena']    = $this->xmlrpc_results('http://b.hatena.ne.jp/xmlrpc', 'bookmark.getCount', $permalink);
        $new_meta['delicious'] = $this->socket_results('http://badges.del.icio.us/feeds/json/url/blogbadge?hash='.md5($permalink), '/”total_posts”:([\d]+?),/');
        $new_meta['livedoor']  = $this->xmlrpc_results('http://rpc.clip.livedoor.com/count', 'clip.getCount', $permalink);
        $new_meta['yahoo']     = $this->socket_results('http://bookmarks.yahoo.co.jp/url?url='.urlencode($permalink), '/<span class="nosaved\d">(\d)人が登録<\/span>/');
        
        if ($new_meta['hatena'])    $meta[2] = $new_meta['hatena'];
        if ($new_meta['delicious']) $meta[3] = $new_meta['delicious'];
        if ($new_meta['livedoor'])  $meta[4] = $new_meta['livedoor'];
        if ($new_meta['yahoo'])     $meta[5] = $new_meta['yahoo'];
        if(!$meta[5]) $meta[5] = 0;
        
        $meta[0] = $meta[2] + $meta[3] + $meta[4] + $meta[5];
        $meta[0] = substr("00000".$meta[0], -5);
        $meta[1]  = time();
        update_post_meta($post->ID, $this->key, implode('<>', $meta));
    }
    
    
    /**
     * IXR_Client
     *
     */
    function xmlrpc_results($uri, $method, $params)
    {
        require_once(ABSPATH.WPINC.'/class-IXR.php');

        $client = new IXR_Client($uri);
        if ($client->query($method, $params)) {
            $response = $client->getResponse();
            return $response[$params];
        } else {
            return false;
        }
    }
    
    
    /**
     * file_get_contents
     *
     */
    function socket_results($url, $match)
    {
        $res = @file_get_contents($url);
        preg_match($match, $res, $results);
    
        if (is_numeric($results[1])) {
            return $results[1];
        } else {
            return false;
        }
    }
    
    
    /**
     *
     *
     */
    function wp_head()
    {
        $pluginurl = $this->plugin_url;
    echo <<<EOT

<link rel="stylesheet" href="{$pluginurl}style.css" type="text/css" media="all" />
<script type="text/javascript" src="{$pluginurl}bookmarkcommentviewer.js" charset="utf-8"></script>

EOT;
    }

}




/**
 *
 *
 */
function SBM_popular_entry_list($limit=10, $filter="", $val="") {
    global $wpdb;
    
    $pluginurl = get_option('siteurl')."/wp-content/plugins/wp-sbm_popular_entry/";
    $metalist = $wpdb->get_results( SBM_popular_entry_list_sql($limit, $filter, $val) );

    if ( $metalist ) {
        ob_start();
        foreach ($metalist as $metarow) {
            $permalink = get_permalink($metarow->ID);
            $title = $metarow->post_title;
            $meta = get_post_meta($metarow->ID, "SBM_count", 1);
            $popup = "iconImageClickHandler(this, '".$permalink."', event)";
            list($count, $icon, $link, $add) = _template_parm($pluginurl, $permalink, $title, $metarow->meta_value);

            if($count['sum'] > 0)
                include('wp-content/plugins/wp-sbm_popular_entry/template_list.php');
        }
        $content = ob_get_contents();
        ob_end_clean();
        echo $content;
    }

}



/**
 *
 *
 */
function SBM_popular_entry_list_autofilter() {

    if(is_category()){
        $filter = "category";
        $val = get_query_var('cat');
    
    }elseif($tags = get_query_var("tag")){
        $filter = "tag";
        $val = $tags;

    }elseif(is_month() || is_day() ){
        $filter = "date";
        $val = get_the_time("Y/m");

    }elseif(is_year()){
        $filter = "date";
        $val = get_the_time("Y");

    }elseif(is_search()){
        $filter = "search";
        $val = get_query_var("s");

    }
    return array($filter, $val);
}



/**
 *
 *
 */
function SBM_popular_entry_list_sql($limit, $filter="", $val="") {
    global $wpdb, $tablepost2tag, $tabletags;

    if($filter == "auto")
        list($filter, $val) = SBM_popular_entry_list_autofilter();

    $val = mysql_real_escape_string($val);

    $sql = "SELECT ID, post_title, meta_value ";

    if($filter == "category") {
        $sql.= "FROM $wpdb->posts, $wpdb->post2cat, $wpdb->postmeta ".
                     "WHERE $wpdb->posts.ID=$wpdb->post2cat.post_id and $wpdb->post2cat.category_id={$val} and ";


    } elseif($filter == "tag") {
        $sql.= "FROM $wpdb->posts, $tablepost2tag, $tabletags, $wpdb->postmeta ".
                     "WHERE $wpdb->posts.ID=$tablepost2tag.post_id and $tabletags.tag_ID=$tablepost2tag.tag_id and $tabletags.tag='{$val}' and ";


    } elseif($filter == "author") {
        $sql.= "FROM $wpdb->posts, $wpdb->postmeta ".
                     "WHERE $wpdb->posts.author={$val} and ";


    } elseif($filter == "search") {
        $sql.= "FROM $wpdb->posts, $wpdb->postmeta ".
                     "WHERE ($wpdb->posts.post_title like '%{$val}%' or $wpdb->posts.post_content like '%{$val}%') and ";


    } elseif($filter == "date") {
        list($opens, $closes) = explode("-", $val);
        if(!$closes) $closes = $opens;
        list($year1, $month1) = explode("/", $opens);
        if(!$month1) $month1 = 1;
        list($year2, $month2) = explode("/", $closes);
        if(!$month2) $month2 = 12;

        $date_open  = date("Y/m/d", mktime(0, 0, 0, floor($month1),   1, $year1));
        $date_close = date("Y/m/d", mktime(0, 0, 0, floor($month2)+1, 1, $year2));

        $sql.= "FROM $wpdb->posts, $wpdb->postmeta ".
                     "WHERE $wpdb->posts.post_date between '{$date_open}' and '{$date_close}' and ";


    } else {
        $sql.= "FROM $wpdb->posts, $wpdb->postmeta ".
                     "WHERE ";

    }

    $sql.= "$wpdb->posts.ID=$wpdb->postmeta.post_id and meta_key = 'SBM_count' ".
                 "ORDER BY meta_value DESC, ID DESC LIMIT ".$limit;

    return $sql;
}



/**
 *
 *
 */
function SBM_count_get() {
global $post;

    $pluginurl = get_option('siteurl')."/wp-content/plugins/wp-sbm_popular_entry/";
    $permalink = get_permalink();
    $title = $post->post_title;
    $meta = get_post_meta($post->ID, "SBM_count", 1);
    $popup = "iconImageClickHandler(this, '".$permalink."', event)";
    list($count, $icon, $link, $add) = _template_parm($pluginurl, $permalink, $title, $meta);

    #ob_start();
    include('wp-content/plugins/wp-sbm_popular_entry/template_post.php');
    #$content = ob_get_contents();
    #ob_end_clean();

    #echo $content;
}


function _template_parm($pluginurl, $permalink, $title, $meta = "00000<>0<>0<>0<>0<>0"){
    $title = rawurlencode($title);

    list($count['sum'], $gettime,
        $count['hatena'],
        $count['delicious'],
        $count['livedoor'],
        $count['yahoo']) = explode("<>", $meta);
    
    $count['sum'] = floor($count['sum']);
    if(!$count['yahoo']) $count['yahoo'] = 0;
    
    $icon['hatena']    = $pluginurl."hatena.gif";
    $icon['delicious'] = $pluginurl."delicious.gif";
    $icon['livedoor']  = $pluginurl."livedoor.gif";
    $icon['yahoo']     = $pluginurl."yahoo.gif";
    $icon['popup']     = $pluginurl."popup.gif";
    
    $link['hatena']    = 'http://b.hatena.ne.jp/entry/'.$permalink;
    $link['delicious'] = 'http://delicious.com/url/'.md5($permalink);
    $link['livedoor']  = 'http://clip.livedoor.com/page/'.$permalink;
    $link['yahoo']     = 'http://bookmarks.yahoo.co.jp/url?url='.$permalink;
    
    $add['hatena']     = "http://b.hatena.ne.jp/append?".$permalink."&amp;h=".$title;
    $add['delicious']  = "http://delicious.com/post?url=".$permalink."&amp;title=".$title;
    $add['livedoor']   = "http://clip.livedoor.com/clip/add?jump=myclip&amp;link=".$permalink."&amp;title=".$title;
    $add['yahoo'] = "javascript:void window.open('http://bookmarks.yahoo.co.jp/bookmarklet/showpopup?t=".$title."&amp;u=".$permalink."&amp;opener=bm&amp;ei=UTF-8′);"; 
    
    return array($count, $icon, $link, $add);
}
?>