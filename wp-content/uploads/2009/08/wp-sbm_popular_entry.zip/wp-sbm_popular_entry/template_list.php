<ul>
<li><a href="<?= $permalink ?>"><?= $title ?></a> (<?= $count['sum'] ?>)</li>
</ul>