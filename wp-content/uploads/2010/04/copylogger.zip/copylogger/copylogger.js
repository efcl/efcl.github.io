var currentScript = (function (e){
    if(e.nodeName.toLowerCase() == 'script') return e;
    return arguments.callee(e.lastChild) 
})(document);

(function(){
var currentPath = currentScript.src;
var currentDirPath = currentPath.substring(0,currentPath.lastIndexOf('/')+1)
var addEvent;
if(document.addEventListener) {
  addEvent = function(node,type,handler){
    node.addEventListener(type,handler,false);
  };
} else if (document.attachEvent) {
  addEvent = function(node,type,handler){
    node.attachEvent('on' + type, function(evt){
      handler.call(node, evt);
    });
  };
}


addEvent(document.body ,"copy", function(evt){
    var sel = (document.all)?document.selection.createRange().text : window.getSelection()+'';
    if(sel){
        copylog(document.title ,location.href, sel);      
    }
})
function copylog(title , url, copyBody){
  if (window.XMLHttpRequest){
    xmlHttp = new XMLHttpRequest();
  }else{
    if (window.ActiveXObject){
      xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }else{
      xmlHttp = null;
    }
  }
  xmlHttp.open("GET", currentDirPath+'dataStorage.php?title='+ encodeURI(title) +'&url='+ encodeURI(url) +'&comment='+encodeURI(copyBody), true);
  xmlHttp.send(null);
}
})();