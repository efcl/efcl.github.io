<?php
mb_language('Japanese');
mb_internal_encoding('UTF-8');
mb_http_output('UTF-8');
if (($_GET["url"] != "") or ($_GET["comment"] != "")) { //もしPOSTに [url] か [comment] があれば
    if ($_GET["title"]) { //もしPOSTに [url] があれば
        $title = $_GET["title"]; //POSTのデータを変数$urlに格納
        if (get_magic_quotes_gpc()) {
            $title = stripslashes("$title");
        } //クォートをエスケープする
        $title = htmlspecialchars(urldecode($title)); //HTMLタグ禁止
    }
    if ($_GET["url"]) { //もしPOSTに [url] があれば
        $url = $_GET["url"]; //POSTのデータを変数$urlに格納
        if (get_magic_quotes_gpc()) {
            $url = stripslashes("$url");
        } //クォートをエスケープする
        $url = htmlspecialchars(urldecode($url)); //HTMLタグ禁止
    }
    if ($_GET["comment"]) { //もしPOSTに [comment] があれば
        $comment = $_GET["comment"]; //POSTのデータを変数$commentに格納
        if (get_magic_quotes_gpc()) {
            $comment = stripslashes("$comment");
        } //クォートをエスケープする
        $comment = htmlspecialchars(urldecode($comment)); //HTMLタグ禁止
        // $comment = mb_strimwidth($comment, 0, 200, "",utf8); // 長いデータを200バイトでカット
    }
    $time = date("Y/n/j G:i"); //日時の取得
    $write = $title."<>".$url."<>".$comment."<>".$time."\r\n"; //新しく書き込むデータを <> で区切って整形
    $log = fopen("./log.txt", "a"); //追記モードでデータを開く（データは空になる）
    flock($log, LOCK_EX); //ファイルロック開始
    fputs($log, $write); //書き込み処理
    flock($log, LOCK_UN); //ファイルロック解除
    fclose($log); //ファイルを閉じる
} 
?>